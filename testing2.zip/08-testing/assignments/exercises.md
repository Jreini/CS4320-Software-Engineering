# Exercises
1. Perform steps outlined in the assignment, in the [README.md](./README.md) file in this directory. This will be a fully functional/improved version of your submission in the prior module.
2. Participate in the Slack Channel on Construction and Testing, helping your course mates when they get "stuck", or soliciting mutual aid when you are "stuck". 