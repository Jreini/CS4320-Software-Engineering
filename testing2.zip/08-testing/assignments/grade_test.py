import Staff

import pytest



username = 'calyam'
password =  '#yeet'
username2 = 'hdjsr7'
username3 = 'yted91'
course = 'cloud_computing'
assignment = 'assignment1'
profUser = 'goggins'
profPass = 'augurrox'

def test_change_grade(staff):
    test = staff.change_grade('calyam','cloud_computing','assignment1',50)
    if not test:
        assert False
    

@pytest.fixture
def Staff_system():
    staff = Staff()
    staff.update_course_db()
    return staff